G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.3*
G04 #@! TF.CreationDate,2026-08-13T10:42:09+05:30*
G04 #@! TF.ProjectId,HeatingElement,48656174-696e-4674-956c-656d656e742e,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.3) date 2026-08-13 10:42:09*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,2.000000X2.000000*%
%ADD11R,4.000000X4.000000*%
%ADD12RoundRect,0.160000X-0.197500X-0.160000X0.197500X-0.160000X0.197500X0.160000X-0.197500X0.160000X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J4*
X174528000Y-150169000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J1*
X163028000Y-150169000D03*
G04 #@! TD*
G04 #@! TO.C,J2*
X183028000Y-150169000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,R1*
X172615000Y-138650000D03*
X173810000Y-138650000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J3*
X171528000Y-150169000D03*
G04 #@! TD*
M02*
